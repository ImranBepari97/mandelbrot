Imran Bepari ----- ib7g15


Hey!

This is my Fractal Explorer.

I have completed all compulsory parts and have added a few extensions.

- Different varieties of Fractals can be viewed, along with their corresponding Julia sets.
- The Julia set has the option to be animated.
- There are RGB Sliders that allow the user to change colours to whatever they want.
- Right Click the main view after zooming in will zoom out.

How to use my Fractal explorer:

Run the MandelbrotGUI class to start the program.

The Editor panel controls the images. Feel free to edit the values and click "Render" in 
order to manipulate the images.

Clicking on the Mandelbrot will freeze and animate the Julia set. Freeze the Julia set on your selected image
so you can save it, which is located on the second tab of Editor. Type in the name of your
image and click "Save". It will be added to the list. As long as the text file that is 
generated is kept with the class files, you should be able to view your favourite fractals
at any time.

Dragging on the Mandelbrot will draw a square, where once the user releases the left mouse
button, the fractal will zoom into that square selection. This can be repeated. If the user
wants to zoom out, they can right click. 

Using the drop down menu on the editor, different Fractals can be selected.



